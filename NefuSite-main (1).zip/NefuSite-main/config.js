module.exports = {
  siteName: "Dongtube",
  authorName: "Hanzy",
  profilePicture: "https://cdn.nefyu.my.id/csy1.jpg",
  profileBanner: "https://cdn.nefyu.my.id/cgxl.png",
  aboutText: "A personal project for file hosting and URL shortening, built with simplicity and efficiency in mind.",
  backgroundImage: "https://cdn.nefyu.my.id/1lsq.webp"
};
