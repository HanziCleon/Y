import fs from "fs";
import chalk from "chalk";

global.owner = ["6283143961588","6283143961588@lid"];
global.mode = false;
global.menuStyle = 'relay';

global.namebotz = "Dongtube";
global.packname = 'https://dongtube.biz.id';
global.nameown = "Hanzy";
global.author = 'https://www.github.com/HanziCleon';
global.footer = "𝗍𝖾𝗅𝖾𝗀𝗋𝖺𝗆: @hanzyy001";

global.YouTube = "https://www.youtube.com/@Hanzyy001";
global.GitHub = "https://github.com/HanziCleon";
global.Telegram = "https://t.me/hanzyy001";
global.ChannelWA = "https://whatsapp.com/channel/0029Vb91qeW17Emm4TVqu53K";
